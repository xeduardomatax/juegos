# 🏗️ ARQUITECTURA Y DIAGRAMAS TÉCNICOS

## Tabla de Contenidos
1. [Arquitectura General](#arquitectura-general)
2. [Diagrama de Flujo - Dificultad](#diagrama-de-flujo---dificultad)
3. [Diagrama de Flujo - Juego](#diagrama-de-flujo---juego)
4. [Diagrama de Flujo - RA](#diagrama-de-flujo---ra)
5. [Estructura de Datos](#estructura-de-datos)
6. [API de Comunicación](#api-de-comunicación)

---

## 🎯 Arquitectura General

### Modelo de 3 Capas

```
┌────────────────────────────────────────────────────────────┐
│                  CAPA DE PRESENTACIÓN (UI)                │
│  ┌──────────────────────────────────────────────────────┐ │
│  │  - Pantalla de Configuración (HTML)                  │ │
│  │  - Pantalla de Juego (HTML)                          │ │
│  │  - Modales de RA (Dinámicos - JavaScript)            │ │
│  │  - Estilos CSS (Animaciones, Temas)                  │ │
│  └──────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────┘
              ↑ Renderiza                ↓ Eventos usuario
┌────────────────────────────────────────────────────────────┐
│              CAPA DE LÓGICA (JavaScript)                   │
│  ┌──────────────────────────────────────────────────────┐ │
│  │  Funciones Principales:                              │ │
│  │  • initializeGame() - Cargar ejercicios              │ │
│  │  • loadExerciseBank() - Filtrar por nivel            │ │
│  │  • startGame() - Iniciar sesión                      │ │
│  │  • displayAROperation() - Mostrar ejercicio          │ │
│  │  • showOptions() - Mostrar respuestas               │ │
│  │  • showARValidationModal() - Panel de validación     │ │
│  │  • showGameCompletedModal() - Panel final            │ │
│  └──────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────┘
              ↑ Lee/Escribe            ↓ Obtiene datos
┌────────────────────────────────────────────────────────────┐
│               CAPA DE DATOS                                │
│  ┌──────────────────────────────────────────────────────┐ │
│  │  Fuentes de Datos:                                   │ │
│  │  • ejercicios.json - Banco de ejercicios             │ │
│  │  • LocalStorage - Configuración de RA                │ │
│  │  • Variables globales - Estado del juego             │ │
│  │  • Servidor (localhost:3001 o Render) - Upload files│ │
│  └──────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────┘
```

### Componentes Principales

```
┌─────────────────────────────────────────────────────────┐
│                    APLICACIÓN                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────────────┐        ┌──────────────────┐     │
│  │  Pantalla 1      │        │  Pantalla 2      │     │
│  │  CONFIGURACIÓN   │───────→│  JUEGO           │     │
│  │                  │        │                  │     │
│  │ • Nivel          │        │ • Operación      │     │
│  │ • Cantidad       │        │ • Opciones       │     │
│  │ • Botón Iniciar  │        │ • Puntuación     │     │
│  └──────────────────┘        └──────────────────┘     │
│                                     ↓                   │
│                              ┌──────────────┐          │
│                              │  Modales RA  │          │
│                              │              │          │
│                              │ • Inicio     │          │
│                              │ • Acierto    │          │
│                              │ • Final      │          │
│                              └──────────────┘          │
│                                                         │
│  ┌────────────────────────────────────────────────┐    │
│  │  ALMACENAMIENTO                                │    │
│  │  • ejercicios.json (ejercicios)               │    │
│  │  • LocalStorage (configuración RA)            │    │
│  │  • gameData (estado actual)                   │    │
│  └────────────────────────────────────────────────┘    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 📊 Diagrama de Flujo - Dificultad

### Paso 1: Cargar Ejercicios

```
┌──────────────────────────────────────────┐
│  window: DOMContentLoaded               │
└─────────────┬──────────────────────────┘
              │
              ▼
┌──────────────────────────────────────────┐
│  initializeGame()                       │
│  fetch('ejercicios.json')              │
└─────────────┬──────────────────────────┘
              │
         ┌────┴────┐
         │          │
         ▼          ▼
    ┌─────────┐ ┌─────────┐
    │ SUCCESS │ │ ERROR   │
    └────┬────┘ └────┬────┘
         │            │
         ▼            ▼
   ┌─────────────┐  ┌──────────────┐
   │ Validar     │  │ Mostrar error│
   │ JSON        │  │ startBtn:    │
   └────┬────────┘  │ disabled     │
        │           └──────────────┘
        ▼
   ┌──────────────┐
   │ Extraer      │
   │ niveles      │
   │ únicos:      │
   │ ["basico",   │
   │  "intermedio"│
   │  "avanzado"] │
   └────┬─────────┘
        │
        ▼
   ┌──────────────────┐
   │ Llenar select    │
   │ #level-select    │
   └────┬─────────────┘
        │
        ▼
   ┌──────────────────┐
   │ Habilitar        │
   │ startGameBtn     │
   └────┬─────────────┘
        │
        ▼
   ┌──────────────────┐
   │ loadExerciseBank()│
   │ (filtrar primer  │
   │  nivel por       │
   │  defecto)        │
   └──────────────────┘
```

### Paso 2: Seleccionar Nivel

```
┌────────────────────────────────────┐
│  Usuario cambia select             │
│  #level-select (ej: "intermedio")  │
└─────────────┬──────────────────────┘
              │
         ┌────┴────────────────┐
         │  addEventListener   │
         │  'change'           │
         └────┬────────────────┘
              │
              ▼
         ┌──────────────────────┐
         │ loadExerciseBank()   │
         └────┬─────────────────┘
              │
              ▼
         ┌─────────────────────────────┐
         │ gameData.filteredExercises │
         │ = exerciseBank.filter(ej   │
         │   => ej.nivel ===           │
         │       "intermedio")         │
         └────┬────────────────────────┘
              │
              ▼
         ┌─────────────────────────────┐
         │ availableExercises.        │
         │ textContent =              │
         │ "✅ 28 ejercicios         │
         │  disponibles para         │
         │  intermedio"              │
         └─────────────────────────────┘
```

### Paso 3: Seleccionar Cantidad

```
┌────────────────────────────────────────┐
│  Usuario cambia select                 │
│  #exercise-count (ej: 3)               │
└─────────────┬─────────────────────────┘
              │
         ┌────┴─────────────────────┐
         │  Valor guardado en:      │
         │  exerciseCountInput      │
         │  .value = "3"            │
         └──────┬────────────────────┘
                │
        (Espera a que usuario presione botón)
```

### Paso 4: Iniciar Juego

```
┌────────────────────────────────────────┐
│  Usuario presiona botón                │
│  "✨ Siguiente"                        │
└─────────────┬─────────────────────────┘
              │
         ┌────┴────────────────────┐
         │  addEventListener       │
         │  click → startGame()    │
         └────┬────────────────────┘
              │
              ▼
    ┌─────────────────────────────────┐
    │ const count =                   │
    │ parseInt(exerciseCountInput     │
    │ .value) = 3                     │
    └────┬────────────────────────────┘
         │
         ▼
    ┌───────────────────────────────────┐
    │ Validar:                          │
    │ gameData.filteredExercises       │
    │ .length > 0 ?                     │
    └────┬────────────┬────────────────┘
         │            │
    ┌────┴─┐      ┌────┴─────┐
    │ YES  │      │ NO        │
    └────┬─┘      └────┬─────┘
         │             │
         ▼             ▼
    ┌────────────┐  ┌──────────────┐
    │ Continuar  │  │ alert('No hay│
    │            │  │ ejercicios') │
    │            │  │ return       │
    │            │  └──────────────┘
    └────┬───────┘
         │
         ▼
    ┌──────────────────────────────┐
    │ shuffled =                   │
    │ filteredExercises.sort(      │
    │   () => Math.random() - 0.5) │
    └────┬─────────────────────────┘
         │
         ▼
    ┌───────────────────────────────┐
    │ selectedExercises =           │
    │ shuffled.slice(0,             │
    │ Math.min(3, shuffled.length)) │
    │ → [ej1, ej2, ej3]             │
    └────┬──────────────────────────┘
         │
         ▼
    ┌───────────────────────────────┐
    │ gameData.currentStep = 0      │
    │ gameData.score = 0            │
    │ gameData.exercises =          │
    │   selectedExercises           │
    └────┬──────────────────────────┘
         │
         ▼
    ┌───────────────────────────────┐
    │ Ocultar generator-screen      │
    │ Mostrar game-screen           │
    └────┬──────────────────────────┘
         │
         ▼
    ┌───────────────────────────────┐
    │ showInstructionsModal()       │
    │ (Panel de INICIO)             │
    └───────────────────────────────┘
```

---

## 🎮 Diagrama de Flujo - Juego

### Mostrar Operación

```
┌──────────────────────────────────────┐
│ displayAROperation()                │
└─────────────┬──────────────────────┘
              │
              ▼
    ┌─────────────────────────────────┐
    │ if currentStep >=                │
    │    exercises.length ?            │
    └────┬────────────────┬──────────┘
         │                │
    ┌────┴─┐          ┌───┴───┐
    │ YES  │          │ NO    │
    └────┬─┘          └───┬───┘
         │                │
         ▼                ▼
    ┌──────────────┐  ┌─────────────────────┐
    │ Mostrar      │  │ currentExercise =   │
    │ panel final  │  │ exercises[currentStep]
    │              │  └──┬──────────────────┘
    │ (TERMINÓ)    │     │
    └──────────────┘     ▼
                    ┌─────────────────────┐
                    │ operation = "3,+2"  │
                    │ options = [{...}]   │
                    └──┬──────────────────┘
                       │
                       ▼
                    ┌─────────────────────┐
                    │ Parsear operación:  │
                    │ ["3", "+", "2"]     │
                    └──┬──────────────────┘
                       │
                       ▼
                    ┌─────────────────────┐
                    │ showNextPart() →    │
                    │ Mostrar lentamente: │
                    │ • 3 (1s)            │
                    │ • + (1s)            │
                    │ • 2 (1s)            │
                    └──┬──────────────────┘
                       │
                       ▼
                    ┌─────────────────────┐
                    │ showOptions()       │
                    └─────────────────────┘
```

### Validar Respuesta

```
┌─────────────────────────────────────┐
│ Usuario selecciona opción y presiona│
│ "Validar resultado"                │
└────────────┬──────────────────────┘
             │
             ▼
    ┌──────────────────────────────┐
    │ if !selectedOption ?         │
    └────┬────────────┬────────────┘
         │            │
    ┌────┴──┐     ┌────┴──┐
    │ YES   │     │ NO    │
    └────┬──┘     └───┬───┘
         │            │
         ▼            ▼
    ┌─────────┐  ┌──────────────────┐
    │ alert   │  │ if selectedOption│
    │ "Selec-"│  │ .isCorrect ?     │
    │ ciona"  │  └────┬────────┬────┘
    └─────────┘       │        │
                  ┌───┴─┐  ┌───┴────┐
                  │YES  │  │ NO     │
                  └──┬──┘  └───┬────┘
                     │        │
                     ▼        ▼
                  ┌────────┐┌──────────┐
                  │score+=10││score += 0│
                  │button: │└──────────┘
                  │'correct'│
                  └───┬────┘
                      │
                      ▼
              ┌──────────────────┐
              │ updateScore()    │
              │ scoreDisplay:=   │
              │ "Puntuación: 10" │
              └───┬──────────────┘
                  │
                  ▼
          ┌────────────────────┐
          │showARValidation    │
          │Modal(isCorrect)    │
          │(Panel ACIERTO)     │
          └───┬────────────────┘
              │
              ▼
          ┌────────────────────┐
          │ Esperar callback   │
          │ (usuario presiona  │
          │  "Siguiente")      │
          └───┬────────────────┘
              │
              ▼
          ┌────────────────────┐
          │ currentStep ++     │
          │ 0 → 1              │
          └───┬────────────────┘
              │
         ┌────┴────┐
         │          │
         ▼          ▼
    ┌──────────┐┌──────────────┐
    │Hay más   ││ Finalizar    │
    │ejercicios?││ (mostrar     │
    └────┬─────┘│ panel final) │
         │      └──────────────┘
    ┌────┴────┐
    │ YES     │
    └────┬────┘
         │
         ▼
    ┌──────────────────┐
    │ displayAROperation()
    │ (Siguiente ejercicio)
    └──────────────────┘
```

---

## 🎨 Diagrama de Flujo - RA

### Panel de Inicio

```
┌──────────────────────────────────────┐
│ showInstructionsModal()              │
└─────────────┬──────────────────────┘
              │
              ▼
    ┌─────────────────────────────────┐
    │ Cargar config desde              │
    │ localStorage                    │
    └────┬────────────────────────────┘
         │
         ▼
    ┌─────────────────────────────────┐
    │ hasContent = config['Inicio'] && │
    │  (Texto || Imagen || Audio ||   │
    │   Video)                        │
    └────┬────────────┬──────────────┘
         │            │
    ┌────┴──┐     ┌────┴────┐
    │ YES   │     │ NO      │
    └────┬──┘     └────┬────┘
         │             │
         ▼             ▼
    ┌──────────┐  ┌────────────┐
    │Crear     │  │Saltar      │
    │modal     │  │directa-    │
    │con       │  │mente a:    │
    │contenido │  │displayAR   │
    │multimedia│  │Operation()│
    └────┬─────┘  └────────────┘
         │
         ▼
    ┌─────────────────────────────┐
    │ Mostrar contenido:          │
    │ • Texto (color #ffd60a)     │
    │ • Imagen (max-width: 180px) │
    │ • Audio (controls, autoplay)│
    │ • Video (autoplay)          │
    └────┬──────────────────────┘
         │
         ▼
    ┌─────────────────────────────┐
    │ Botón: "Comenzar juego"     │
    │ → displayAROperation()      │
    └─────────────────────────────┘
```

### Panel de Acierto

```
┌──────────────────────────────────────┐
│ showARValidationModal(isCorrect)     │
└─────────────┬──────────────────────┘
              │
              ▼
    ┌─────────────────────────────────┐
    │ if isCorrect && hasContent ?    │
    └────┬────────────┬──────────────┘
         │            │
    ┌────┴──┐     ┌────┴─────┐
    │ YES   │     │ NO       │
    └────┬──┘     └────┬─────┘
         │             │
         ▼             ▼
    ┌──────────────┐┌─────────────┐
    │Mostrar       ││Mostrar msg. │
    │contenido    ││motivacional │
    │Config.      ││(no multimedia)
    │['Acierto']  ││             │
    └────┬────────┘└────┬────────┘
         │               │
         ▼               ▼
    ┌─────────────────────────────┐
    │ • Texto: config['Acierto']  │
    │          ['TextoValor']     │
    │ • Imagen: config['Acierto'] │
    │           ['ImagenUrl']     │
    │ • Audio: reproduce auto     │
    │ • Video: reproduce auto     │
    └────┬──────────────────────┘
         │
         ▼
    ┌──────────────────────────────┐
    │ isLastExercise ?             │
    │ (currentStep + 1 >=          │
    │  exercises.length)           │
    └────┬────────────┬────────────┘
         │            │
    ┌────┴──┐     ┌────┴───┐
    │ YES   │     │ NO     │
    └────┬──┘     └───┬────┘
         │            │
         ▼            ▼
    ┌──────────────┐┌──────────────┐
    │"Finalizar"   ││"Siguiente ej"│
    └────┬─────────┘└────┬─────────┘
         │                │
         ▼                ▼
    ┌────────────────────────┐
    │ Usuario presiona botón │
    │ → callback()           │
    └────┬───────────────────┘
         │
         ▼
    ┌────────────────────────────┐
    │ if isLastExercise:         │
    │   showGameCompletedModal() │
    │ else:                      │
    │   displayAROperation()     │
    └────────────────────────────┘
```

### Panel Final

```
┌──────────────────────────────────────┐
│ showGameCompletedModal(score)        │
└─────────────┬──────────────────────┘
              │
              ▼
    ┌─────────────────────────────────┐
    │ config['Final'] ?                │
    └────┬────────────┬──────────────┘
         │            │
    ┌────┴──┐     ┌────┴──┐
    │ YES   │     │ NO    │
    └────┬──┘     └───┬───┘
         │            │
         ▼            ▼
    ┌──────────────┐┌──────────┐
    │Mostrar       ││Retornar  │
    │contenido     ││(no mostrar
    │multimedia    ││panel)     │
    └────┬─────────┘└──────────┘
         │
         ▼
    ┌──────────────────────────┐
    │ Mostrar:                 │
    │ • Puntuación final:      │
    │   "Puntuación: 20 pts"   │
    │ • Texto (config)         │
    │ • Imagen (config)        │
    │ • Audio (config)         │
    │ • Video (config)         │
    └────┬─────────────────────┘
         │
         ▼
    ┌──────────────────────────┐
    │ Botón: "Volver al Menú"  │
    │ → Reiniciar aplicación   │
    └──────────────────────────┘
```

---

## 🗂️ Estructura de Datos

### Objeto gameData

```javascript
const gameData = {
    // Operación actual a resolver
    operation: "3,+2,-1,+4,-2",
    
    // Opciones de respuesta
    options: [
        { text: "6", isCorrect: true },
        { text: "5", isCorrect: false },
        { text: "7", isCorrect: false }
    ],
    
    // Índice del ejercicio actual (0-indexed)
    currentStep: 0,
    
    // Puntuación acumulada (suma de 10 puntos por acierto)
    score: 0,
    
    // Tiempo de visualización (milisegundos)
    displayTime: 500,
    
    // Array de ejercicios a resolver (seleccionados y mezclados)
    exercises: [
        {
            "nivel": "basico",
            "operation": "3,+2,-1,+4,-2",
            "options": [
                { "text": "6", "isCorrect": true },
                { "text": "5", "isCorrect": false },
                { "text": "7", "isCorrect": false }
            ]
        },
        // ... más ejercicios ...
    ],
    
    // Array de ejercicios disponibles (filtrados por nivel actual)
    filteredExercises: [
        // ... ejercicios del nivel seleccionado ...
    ]
};
```

### Estructura de Configuración de RA

```javascript
const gameConfig = {
    // Etapa: Inicio (antes del juego)
    "Inicio": {
        "Texto": true,
        "TextoValor": "¡Bienvenido!",
        "Imagen": true,
        "ImagenUrl": "https://servidor.com/imagen.jpg",
        "Audio": false,
        "AudioUrl": "",
        "Video": false,
        "VideoUrl": ""
    },
    
    // Etapa: Acierto (cuando responde correctamente)
    "Acierto": {
        "Texto": true,
        "TextoValor": "¡CORRECTO!",
        "Imagen": true,
        "ImagenUrl": "https://servidor.com/estrella.png",
        "Audio": true,
        "AudioUrl": "https://servidor.com/aplausos.mp3",
        "Video": false,
        "VideoUrl": ""
    },
    
    // Etapa: Final (después de completar todos)
    "Final": {
        "Texto": true,
        "TextoValor": "¡Juego completado!",
        "Imagen": false,
        "ImagenUrl": "",
        "Audio": false,
        "AudioUrl": "",
        "Video": true,
        "VideoUrl": "https://servidor.com/resumen.mp4"
    }
};

// Se guarda en localStorage
localStorage.setItem('gameConfig', JSON.stringify(gameConfig));
```

---

## 🔗 API de Comunicación

### Conexión con el Servidor

```javascript
// Detección automática de servidor
const SERVER_URL = window.location.hostname === 'localhost' || 
                   window.location.hostname === '127.0.0.1'
    ? 'http://localhost:3001'        // Desarrollo local
    : 'https://juegos-o3jk.onrender.com';  // Producción
```

### Endpoints Disponibles

```
┌─────────────────────────────────────────────────────────┐
│           ENDPOINTS DEL SERVIDOR                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  POST /upload-image                                    │
│  ├─ Multipart: FormData { image: File }               │
│  ├─ Validación: .jpg, .jpeg, .png (max 5MB)           │
│  └─ Respuesta: { success: true, url: "..." }          │
│                                                         │
│  POST /upload-audio                                    │
│  ├─ Multipart: FormData { audio: File }               │
│  ├─ Validación: .mp3 (max 3MB)                        │
│  └─ Respuesta: { success: true, url: "..." }          │
│                                                         │
│  POST /upload-video                                    │
│  ├─ Multipart: FormData { video: File }               │
│  ├─ Validación: .mp4 (max 10MB)                       │
│  └─ Respuesta: { success: true, url: "..." }          │
│                                                         │
│  GET /imagenes/ultima                                  │
│  └─ Respuesta: { url: "última imagen subida" }        │
│                                                         │
│  GET /audios/ultima                                    │
│  └─ Respuesta: { url: "último audio subido" }         │
│                                                         │
│  GET /videos/ultima                                    │
│  └─ Respuesta: { url: "último video subido" }         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### Ejemplo de Llamada con Reintentos

```javascript
// Función robusta con reintentos automáticos
async function fetchWithRetry(url, options = {}, maxRetries = 3) {
    let lastError;
    
    for (let i = 0; i < maxRetries; i++) {
        try {
            const response = await fetch(url, {
                ...options,
                timeout: 30000  // 30 segundos
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            return response;  // Éxito
        } catch (error) {
            lastError = error;
            
            if (i < maxRetries - 1) {
                // Espera exponencial antes de reintentar
                const waitTime = 1000 * (i + 1);  // 1s, 2s, 3s
                console.log(`Reintentando en ${waitTime}ms... (intento ${i + 2}/${maxRetries})`);
                await new Promise(resolve => setTimeout(resolve, waitTime));
            }
        }
    }
    
    throw lastError;
}

// Ejemplo de uso
async function uploadImage(file) {
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        const response = await fetchWithRetry(
            `${SERVER_URL}/upload-image`,
            { method: 'POST', body: formData }
        );
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error final:', error);
        return { success: false, error: error.message };
    }
}
```

### Secuencia de Carga de Archivo

```
┌─────────────────────────────────────┐
│  Usuario selecciona archivo         │
└────────────┬──────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  Validar tipo y tamaño              │
│  (local en el navegador)            │
└────────────┬──────────────────────┘
             │
        ┌────┴────┐
        │          │
    ┌───┴──┐  ┌────┴──┐
    │ OK   │  │ ERROR │
    └───┬──┘  └───┬───┘
        │        │
        ▼        ▼
    ┌────────┐┌──────────┐
    │Crear   ││Mostrar   │
    │FormData││error     │
    └────┬───┘└──────────┘
         │
         ▼
    ┌──────────────────────┐
    │ fetchWithRetry()     │
    │ (con reintentos)     │
    └────┬─────────────────┘
         │
    ┌────┴────┐
    │          │
┌───┴──┐  ┌────┴───┐
│ OK   │  │ ERROR  │
└───┬──┘  └────┬───┘
    │          │
    ▼          ▼
┌────────┐┌─────────────┐
│Guardar ││Intentar de  │
│URL en  ││nuevo (hasta │
│config  ││3 veces)    │
└────────┘└─────────────┘
```

---

## 📱 Ciclo de Vida de la Aplicación

```
┌──────────────────────────────────────────────────────────┐
│                CARGA INICIAL                            │
├──────────────────────────────────────────────────────────┤
│ 1. HTML se carga                                        │
│ 2. CSS se aplica                                        │
│ 3. JavaScript se ejecuta                                │
│ 4. window.addEventListener('DOMContentLoaded', ...)    │
│ 5. initializeGame() se llama                           │
│ 6. ejercicios.json se carga                            │
│ 7. gameDat se inicializa con primer nivel              │
│ 8. Interfaz de configuración está lista                │
└──────────────────────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────────────────────┐
│            CONFIGURACIÓN DEL USUARIO                    │
├──────────────────────────────────────────────────────────┤
│ 1. Usuario selecciona nivel                            │
│ 2. loadExerciseBank() filtra ejercicios                │
│ 3. Usuario selecciona cantidad                         │
│ 4. Usuario presiona "Siguiente"                        │
│ 5. startGame() prepara la sesión                       │
└──────────────────────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────────────────────┐
│              JUEGO EN PROGRESO                          │
├──────────────────────────────────────────────────────────┤
│ 1. displayAROperation() muestra operación              │
│ 2. Usuario ve cada paso de la operación                │
│ 3. showOptions() muestra respuestas posibles           │
│ 4. Usuario selecciona opción                           │
│ 5. Validación: correcta/incorrecta                     │
│ 6. showARValidationModal() muestra panel               │
│ 7. Usuario presiona "Siguiente"                        │
│ 8. currentStep++ (siguiente ejercicio)                 │
│ 9. Repetir para todos los ejercicios                   │
└──────────────────────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────────────────────┐
│              JUEGO COMPLETADO                           │
├──────────────────────────────────────────────────────────┤
│ 1. showGameCompletedModal() muestra resumen            │
│ 2. Puntuación final visible                            │
│ 3. Panel final con contenido multimedia                │
│ 4. Usuario puede presionar "Volver al Menú"            │
│ 5. Reinicia el flujo                                   │
└──────────────────────────────────────────────────────────┘
```

---

**Creado para:** Documentación Técnica - Proyecto Educativo
**Versión:** 1.0
**Fecha:** Noviembre 2025

